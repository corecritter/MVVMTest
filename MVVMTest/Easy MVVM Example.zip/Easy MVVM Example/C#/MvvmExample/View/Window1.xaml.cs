﻿using System.Windows;

namespace MvvmExample.ViewModel
{
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }
    }
}
