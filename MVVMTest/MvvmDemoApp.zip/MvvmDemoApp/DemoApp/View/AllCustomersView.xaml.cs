﻿namespace DemoApp.View
{
    public partial class AllCustomersView : System.Windows.Controls.UserControl
    {
        public AllCustomersView()
        {
            InitializeComponent();
        }
    }
}