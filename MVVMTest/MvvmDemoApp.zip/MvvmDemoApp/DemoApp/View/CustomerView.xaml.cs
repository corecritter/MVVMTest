﻿namespace DemoApp.View
{
    public partial class CustomerView : System.Windows.Controls.UserControl
    {
        public CustomerView()
        {
            InitializeComponent();
        }
    }
}